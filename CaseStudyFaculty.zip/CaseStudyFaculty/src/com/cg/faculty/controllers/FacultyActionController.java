package com.cg.faculty.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.faculty.beans.Session;
import com.cg.faculty.exceptions.SessionServicesDownException;
import com.cg.faculty.services.FacultyServices;

@Controller
public class FacultyActionController {

	@Autowired(required=true)
	private FacultyServices facultyServices;
	
	@RequestMapping(value="/updateSession",method=RequestMethod.POST)
	public ModelAndView updateSession(@ModelAttribute("session") Session session) {
		
		try {
			session=facultyServices.updateSessionDetails(session);
			ModelAndView modelAndView = new ModelAndView("updateSuccessfulPage", "session", session);
			return modelAndView;
		} catch (SessionServicesDownException e) {
			e.printStackTrace();
		}
		return new ModelAndView("errorPage");
	}
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView getAllSession() {
		try {
			ArrayList<Session> allSessions=facultyServices.getAllSessionDetails();
			ModelAndView modelAndView=new ModelAndView("ScheduledSessions","allSessions",allSessions);
			System.out.println(allSessions);
			//modelAndView.addObject(allSessions);
			return modelAndView;
		} catch (SessionServicesDownException e) {
			e.printStackTrace();
		}
		return new ModelAndView("errorPage");
	}
	
	@RequestMapping(value="/getSession",method=RequestMethod.GET)
	public ModelAndView getSessionDetails(@RequestParam("id") int id) throws SessionServicesDownException {
		System.out.println("aa gya");
		Session session=facultyServices.getSessionDetails(id);
		ModelAndView modelAndView = new ModelAndView("UpdateDetails", "session", session);
		return modelAndView;
		
	}
}
