package com.cg.faculty.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.faculty.beans.Session;

public interface FacultyDAOServices extends JpaRepository<Session, Integer> {

}
